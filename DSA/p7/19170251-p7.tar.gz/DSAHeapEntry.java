public class DSAHeapEntry {

    // CLASS FIELDS
    public int priority;
    public Object value;

    public DSAHeapEntry(int inPriority, Object inValue) {

	priority = inPriority;
	value = inValue;

    };

}
