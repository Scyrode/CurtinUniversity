public class DSAStack {
    
    // CLASSFIELDS
    private DSALinkedList stack;

    // DEFAULT CONSTRUCTOR
    public DSAStack() {

	stack = new DSALinkedList();

    }

    public boolean isEmpty() {
	return stack.isEmpty();
    }

    // MUTATORS
    public void push(Object value) {
	stack.insertFirst(value);
    }

    public Object pop() {

	Object topVal = (Object) stack.removeFirst();
	return topVal;

    }


    public Object top() {
	
	Object topVal;

	topVal = stack.peekLast();

	return topVal;

    }

}

