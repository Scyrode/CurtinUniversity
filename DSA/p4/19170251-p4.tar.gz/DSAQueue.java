public class DSAQueue {
    
    // CLASSFIELDS
    private DSALinkedList queue;

    // DEFAULT CONSTRUCTOR
    public DSAQueue() {
	queue = new DSALinkedList();
    }

    public boolean isEmpty() {
	return queue.isEmpty();
    }

    // MUTATORS
    public void enqueue(Object value) {
	queue.insertLast(value);
    }

    public Object dequeue() {
	return (Object) queue.removeFirst();
    }


    public Object peek() {
	
	Object topVal;

	if (this.isEmpty()) {
	    throw new ArrayIndexOutOfBoundsException("Stack is empty");
	} else {

	    topVal = queue.peekFirst();
	    return topVal;

	}

    }

}

