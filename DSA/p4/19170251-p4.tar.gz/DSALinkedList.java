import java.util.*;

public class DSALinkedList implements Iterable {

    private DSAListNode head;
    private DSAListNode tail;

    //DEFAULT CONSTRUCTOR:
    public DSALinkedList() {

	head = null;
	tail = null;

    }

    //MUTATORS:
    public void insertFirst(Object newValue) {

	DSAListNode newNd = new DSAListNode(newValue);
	if (isEmpty()) {
	    head = newNd;
	    tail = newNd;
	} else {
	    newNd.setNext(head);
	    head = newNd;
	}

    }

    public void insertLast(Object newValue) {
	
	DSAListNode newNd = new DSAListNode(newValue);
	if (isEmpty()) {
	    head = newNd;
	    tail = newNd;
	} else {
	    tail.setNext(newNd);
	    newNd.setPrev(tail);
	    tail = newNd;
	}

    }

    public Object removeFirst() {

	Object nodeValue;

	if (isEmpty()) {
	    throw new IllegalArgumentException("LinkedList is empty");
	} else if (head.getNext() == null) {
	    
	    nodeValue = head.getValue();
	    head = head.getNext();
	    tail = tail.getNext();
	    
	} else {
	    
	    nodeValue = head.getValue();
	    head = head.getNext();
	    head.setPrev(null);

	}

	return nodeValue;

    }

    public Object removeLast() {

	Object nodeValue;

	if (isEmpty()) {
	    throw new IllegalArgumentException("LinkedList is empty");
	} else if (head.getNext() == null) {

	    nodeValue = head.getValue();
	    head = null;
	    tail = null;

	} else {

	    nodeValue = tail.getValue();
	    tail = tail.getPrev();
	    tail.setNext(null);

	}

	return nodeValue;

    }


    //ACCESSORS:
    public boolean isEmpty() {

	boolean empty = false;
	if (head == null) {
	    empty = true;
	}

	return empty;

    }

    public Object peekFirst() {

	Object nodeValue;

	if (isEmpty()) {
	    throw new IllegalArgumentException("LinkedList is empty");
	} else {
	    nodeValue = head.getValue();
	}

	return nodeValue;

    }

    public Object peekLast() {

	Object nodeValue;

	if (isEmpty()) {
	    throw new IllegalArgumentException("LinkedList is empty");
	} else {
	    nodeValue = tail.getValue();
	}

	return nodeValue;

    }

    //PRIVATE DSALISTNODE:
    private class DSAListNode {

	private Object value;
	private DSAListNode next;
	private DSAListNode prev;

	//ALTERNATE CONSTRUCTOR:
	public DSAListNode(Object inValue) {
	    
	    if (inValue != null) {
		value = inValue;
	    } else {
		throw new IllegalArgumentException ("invalid imported value");
	    }

	    next = null;
	    prev = null;
	    
	}

	//ACCESSORS:
	public Object getValue() {
	    return value;
	}

	public DSAListNode getNext() {
	    return next;
	}

	public DSAListNode getPrev() {
	    return prev;
	}

	//MUTATORS:
	

	public void setNext(DSAListNode newNext) {
	    next = newNext;
	}

	public void setPrev(DSAListNode newPrev) {
	    prev = newPrev;
	}

	/* UNUSED MUTATOR:
	public void setValue(Object inValue) {
	    if (inValue == null) {
		throw new IllegalArgumentException("invalid imported value");
	    } else {
		value = inValue;
	    }
	} */

    }

    public Iterator iterator() {
	return new DSALinkedListIterator(this);
    }

    private class DSALinkedListIterator implements Iterator {
	
	private DSAListNode iterNext;

	public DSALinkedListIterator(DSALinkedList theList) {
	    iterNext = theList.head;
	}

	//iterator interface implementation:
	public boolean hasNext() { return (iterNext != null); }
	
	public Object next() {
	    
	    Object value;

	    if (iterNext == null) {
		value = null;
	    } else {
		value = iterNext.getValue();
		iterNext = iterNext.getNext();
	    }

	    return value;

	}

	public void remove() { throw new UnsupportedOperationException("Not supported"); }

    }

}
