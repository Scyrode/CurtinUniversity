// DSAQueue.java Test Harness

public class DSAQueueTestHarness {
    
    public static void main(String[] args)
    {
	
	DSAQueue queue1 = new DSAQueue();
	DSAQueue queue2 = new DSAQueue();

	if (queue1.isEmpty()) {
	    System.out.println("queue1 is empty");

	}

	if (queue2.isEmpty()) {
	     System.out.println("queue2 is empty");

	}

	Integer number = 0;

	queue1.enqueue(number);

	number = 1;

	queue1.enqueue(number);

	number = 2;

	queue2.enqueue(number);

	number = 3;

	queue2.enqueue(number);

	if (queue1.isEmpty()) {
	    System.out.println("queue1 is empty");

	}

	if (queue2.isEmpty()) {
	     System.out.println("queue2 is empty");

	}

	int result = (int) queue1.dequeue();

	System.out.println(result);

	result = (int) queue2.dequeue();

	System.out.println(result);

	result = (int) queue1.dequeue();

	System.out.println(result);

	result = (int) queue2.dequeue();

	System.out.println(result);

    }

}
