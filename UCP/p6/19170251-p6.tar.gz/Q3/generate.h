#ifndef GENERATE_H

#define GENERATE_H
#define LINE_LENGTH 1000

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "randomarray.h"

#endif
