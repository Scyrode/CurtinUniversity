#ifndef DISPLAY_H

#define DISPLAY_H
#define LINE_LENGTH 1000

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "plot.h"

#endif
