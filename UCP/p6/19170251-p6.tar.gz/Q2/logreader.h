#ifndef LOGREADER_H

#define LOGREADER_H
#define INPUT_SIZE 150
#define TRUE 1
#define FALSE 0
#define TIMEINDEX 7

#include <stdio.h>
#include <stdlib.h>
#include <string.h>



#endif
