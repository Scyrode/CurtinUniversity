#ifndef COPYINGFILES_H
#define COPYINGFILES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#endif
