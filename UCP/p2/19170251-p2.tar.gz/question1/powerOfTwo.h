#include <stdio.h>

int powerOfTwo(void);
