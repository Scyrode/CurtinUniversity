#!/bin/bash

for file in $*; do

    echo $file | rev

done
