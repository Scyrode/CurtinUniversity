#ifndef USER_INPUT_H
#define USER_INPUT_H

#include <stdio.h>

void readInts(int* x, int* y, int* z, char* ch);

#endif
