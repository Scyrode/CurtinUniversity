#ifndef RANDOMNUMBER_H
#define RANDOMNUMBER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARRAYLENGTH 5

void* randFunction(void* array[], int length);

#endif
