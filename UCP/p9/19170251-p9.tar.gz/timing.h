#ifndef TIMING_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void sleepFunction(int seconds);

#endif
