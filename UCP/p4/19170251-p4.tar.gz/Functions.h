#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int sum(int array[], int arrayLength);
int max(int array[], int arrayLength);
void reverse(int array[], int arrayLength);
void StringtoInt(char* charArray[], int* intArray, int arrayLength);
void arrayOutput(int array[], int arrayLength);
void toUpperCase(char* choice);

#endif
