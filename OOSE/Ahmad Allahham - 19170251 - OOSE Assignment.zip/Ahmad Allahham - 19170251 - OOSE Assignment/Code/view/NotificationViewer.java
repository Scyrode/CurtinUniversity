/**
 * NotificationViewer
 */

package view;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import controller.NotificationController;
import controller.Exceptions.*;
import model.NotificationsManager;
import model.NotificationsObserver;
import model.PolicyAreaObserver;
import model.Exceptions.AddNotificationException;
import model.Exceptions.RemoveNotificationException;

public class NotificationViewer implements NotificationsObserver {

    private NotificationsManager model;
    private NotificationController controller;
    private Scanner sc;

    public NotificationViewer(NotificationsManager model, NotificationController controller)
    {
        
        this.model = model;
        this.controller = controller;

        this.model.addObserver(this);

        sc = new Scanner(System.in);
        
    }

    public void displayWelcomeMenu()
    {

        // display welcome message
        System.out.println("#################################################");
        System.out.println("<-- WELCOME TO THE ELECTION CAMPAIGN MANAGER --> ");
        System.out.println("#################################################");
        
    }

    public void displayInitialMenu()
    {

        int choice = 0;

        do {
            
            System.out.println("\nChoose one of the following options:\n");

            // display available options
            System.out.println("(1) People Menu");
            System.out.println("(2) Policy Area Menu");
            System.out.println("(3) FileIO Menu");
            System.out.println("(4) Change Notifications Menu");
            System.out.println("(5) Keywords Menu");
            System.out.println("(6) Talking Points Menu");
            System.out.println("(7) Exit");

            try {

                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        this.displayPersonMenu();
                        break;
                    
                    case 2:
                        this.displayPolicyAreaMenu();
                        break;

                    case 3:
                        this.displayFileIOMenu();
                        break;

                    case 4:
                        this.displayNotificationsMenu();
                        break;

                    case 5:

                        this.displayKeywordsMenu();
                        break;

                    case 6:

                        this.displayTalkingPointsMenu();
                        break;

                    case 7:
                        System.exit(0);
                        break;
                        
                    default:
                        System.out.println("\nERROR: must enter a value between 1 and 7");

                }
                
            } catch (InputMismatchException e) {

                System.out.println("\nError: must enter integer");
                sc.next();
    
            }
                
        } while (true);
        
    }

    public void displayPersonMenu()
    {

        // used for removing a person from the model
        int id;

        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Add Person");
        System.out.println("(2) Remove Person");
        System.out.println("(3) Display People");
        System.out.println("(4) Back");

        try {

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    this.getPersonDetails();
                    break;
                
                case 2:

                    System.out.println("\nEnter the person's id");
                    id = sc.nextInt();
                    sc.nextLine();

                    try {
                        controller.removePerson(id);
                        System.out.println("\nPerson Removed!");
                    } catch (RemovePersonException e) {
                        System.out.println("\n" + e.getMessage());
                    }
                    
                    break;

                case 3:
                    
                    System.out.println(controller.displayPeople());
                    break;

                case 4:
                    break;
                
                default:
                    System.out.println("\nERROR (PEOPLE MENU): must enter a value between 1 and 4");
                    break;

            }
            
        } catch (IllegalArgumentException e) {

            System.out.println("\nError: must enter integer");

        }

    }

    private void getPersonDetails()
    {

        String name;
        String type;
        int id;
        Map<String, String> contactDetails = new HashMap<>();

        String choice;

        // used for inputting mobile phone, twitter and facebook contact details
        String contactDetail;

        // get person details
        System.out.println("\nEnter the person's name");
        name = sc.nextLine();

        System.out.println("\nEnter the person's type (Candidate, Volunteer, Strategist)");
        type = sc.nextLine();

        System.out.println("\nEnter the person's id");
        id = sc.nextInt();
        sc.nextLine();

        System.out.println("\nDo they have a phone number? (Y/N)");
        choice = sc.nextLine();

        if (choice.equalsIgnoreCase("y"))
        {

            System.out.println("\nEnter their phone number");
            contactDetail = sc.nextLine();
            contactDetails.put("SMS", contactDetail);
            
        }

        choice = "";

        System.out.println("\nDo they have a Facebook account? (Y/N)");
        choice = sc.nextLine();

        if (choice.equalsIgnoreCase("y"))
        {

            System.out.println("\nEnter their Facebook ID");
            contactDetail = sc.nextLine();
            contactDetails.put("Facebook", contactDetail);
            
        }

        choice = "";

        System.out.println("\nDo they have a Twitter account? (Y/N)");
        choice = sc.nextLine();

        if (choice.equalsIgnoreCase("y"))
        {

            System.out.println("\nEnter their Twitter ID");
            contactDetail = sc.nextLine();
            contactDetails.put("Twitter", contactDetail);
            
        }

        try {
            controller.addPerson(name, type, id, contactDetails);
            System.out.println("\nPerson Added!");
        } catch (AddPersonException e) {
            System.out.println("\n" + e.getMessage());
        }
        
    }

    public void displayPolicyAreaMenu()
    {

        // used for removing policy area from model
        String name;
        
        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Add Policy Area");
        System.out.println("(2) Remove Policy Area");
        System.out.println("(3) Display Policy Areas");
        System.out.println("(4) Back");

        try {

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    System.out.println("\nEnter Policy Area's Name");
                    name = sc.nextLine();
                    
                    try {
                        controller.addPolicyArea(name);
                        System.out.println("\nPolicy Area Added!");
                    } catch (AddPolicyAreaException e) {
                        System.out.println("\n" + e.getMessage());
                    }
                    
                    break;
                
                case 2:

                    System.out.println("\nEnter Policy Area's Name");
                    name = sc.nextLine();
                    
                    try {
                        controller.removePolicyArea(name);
                        System.out.println("\nPolicy Area Removed!");
                    } catch (RemovePolicyAreaException e) {
                        System.out.println("\n" + e.getMessage());
                    }

                case 3:

                    System.out.println(controller.displayPolicyAreas());
                    break;

                case 4:
                    break;
                
                default:
                    System.out.println("\nERROR (POLICY AREA MENU): must enter a value between 1 and 4");
                    break;

            }
            
        } catch (InputMismatchException e) {

            System.out.println("\nError: must enter integer");

        }

    }

    public void displayFileIOMenu()
    {

        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Read File");
        System.out.println("(2) Write File");
        System.out.println("(3) back");

        try {

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    try {

                        controller.readInfo();
                        System.out.println("\nfile read!");
                        
                    } catch (ReadInfoException e) {
                        System.out.println("\n" + e.getMessage());
                    }
                    
                    break;
                
                case 2:
                
                    controller.writeInfo();
                    System.out.println("\nfile written!");
                    
                    break;

                case 3:
                    break;
                
                default:
                    System.out.println("\nERROR (FILE IO MENU): must enter a value between 1 and 3");
                    break;

            }
            
        } catch (IllegalArgumentException e) {

            System.out.println("\nError: must enter integer");

        }

    }
    
    public void displayNotificationsMenu()
    {

        int personId;
        String policyAreaName;
        
        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Add Notification Setting");
        System.out.println("(2) Remove Notification Setting");
        System.out.println("(3) back");

        try {

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    try {
                        
                        System.out.println("\nEnter person's id you would like to associate to a particular Policy Area");
                        personId = sc.nextInt();
                        sc.nextLine();

                        System.out.println("\nEnter the name of the Policy Area you would like to associate with the mentioned person");
                        policyAreaName = sc.nextLine();

                        controller.addNotificationSetting(personId, policyAreaName);
                        System.out.println("\nNotification Setting Added!");

                    } catch (AddNotificationException e) {
                        System.out.println("\n" + e.getMessage());
                    } catch (InputMismatchException e) {
                        System.out.println("\n" + e.getMessage());
                    }

                    break;
                
                case 2:

                    try {
                        
                        System.out.println("\nEnter person's id you would like to associate to a particular Policy Area");
                        personId = sc.nextInt();
                        sc.nextLine();

                        System.out.println("\nEnter the name of the Policy Area you would like to associate with the mentioned person");
                        policyAreaName = sc.nextLine();

                        controller.removeNotificationSetting(personId, policyAreaName);
                        System.out.println("]nNotification Setting Removed");

                    } catch (RemoveNotificationException e) {
                        System.out.println("\n" + e.getMessage());
                    } catch (InputMismatchException e) {
                        System.out.println("\n" + e.getMessage());
                    }
                    
                    break;

                case 3:
                    break;
                
                default:
                    System.out.println("\nERROR (NOTIFICATION SETTING MENU): must enter a value between 1 and 3");
                    break;

            }
            
        } catch (InputMismatchException e) {

            System.out.println("Error: must enter integer");

        }
        
    }

    public void displayKeywordsMenu()
    {

        String keyword;
        String policyAreaName;
        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Add Keyword");
        System.out.println("(2) Remove Keyword");
        System.out.println("(3) back");

        try {

            choice = sc.nextInt();
            sc.nextLine();
            
            switch(choice)
            {

                case 1:
                
                    System.out.println("\nEnter Keyword you would like to add");
                    keyword = sc.nextLine();

                    System.out.println("\nEnter the name of the Policy Area you would like to add this keyword under");
                    policyAreaName = sc.nextLine();

                    try {
                        controller.addKeyword(keyword, policyAreaName);
                        System.out.println("\nKeyword Added!");
                    } catch (AddKeywordException e) {
                        System.out.println("\n" + e.getMessage());
                    }
                    
                    break;

                case 2:

                    System.out.println("\nEnter Keyword you would like to remove");
                    keyword = sc.nextLine();

                    System.out.println("\nEnter the name of the Policy Area you would like to remove this keyword from");
                    policyAreaName = sc.nextLine();

                    try {
                        controller.removeKeyword(keyword, policyAreaName);
                        System.out.println("\nKeyword Removed!");
                    } catch (RemoveKeywordException e) {
                        System.out.println("\n" + e.getMessage());
                    }

                    break;

                case 3:

                    break;

                default:
                    System.out.println("\nERROR (KEYWORD MENU): must enter a value between 1 and 3");
                    break;
                
            }
            
        } catch (InputMismatchException e) {
            System.out.println("\nError: must enter integer");
        }

    }

    public void displayTalkingPointsMenu()
    {

        String talkingPoint;
        String policyAreaName;
        int choice;

        System.out.println("\nChoose one of the following options:\n");

        // display available options
        System.out.println("(1) Add Talking Point");
        System.out.println("(2) Remove Talking Point");
        System.out.println("(3) back");

        try {

            choice = sc.nextInt();
            sc.nextLine();
            
            switch(choice)
            {

                case 1:

                    System.out.println("\nEnter Talking Point you would like to add");
                    talkingPoint = sc.nextLine();

                    System.out.println("\nEnter the name of the Policy Area you would like to add this Talking Point under");
                    policyAreaName = sc.nextLine();

                    try {
                        controller.addTalkingPoint(talkingPoint, policyAreaName);
                        System.out.println("\nTalking Point Added!");
                    } catch (AddTalkingPointException e) {
                        System.out.println("\n" + e.getMessage());
                    }

                    break;

                case 2:

                    System.out.println("\nEnter Talking Point you would like to remove");
                    talkingPoint = sc.nextLine();

                    System.out.println("\nEnter the name of the Policy Area you would like to remove this Talking Point from");
                    policyAreaName = sc.nextLine();

                    try {
                        controller.removeTalkingPoint(talkingPoint, policyAreaName);
                        System.out.println("\nTalking Point Removed!");
                    } catch (RemoveTalkingPointException e) {
                        System.out.println("\n" + e.getMessage());
                    }

                    break;

                case 3:

                    break;

                default:
                    System.out.println("\nERROR (TALKING POINT MENU): must enter a value between 1 and 3");
                    break;
                
            }
            
        } catch (InputMismatchException e) {
            System.out.println("Error: must enter integer");
        }
        
    }

    public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea)
    {
        System.out.println("Added Keyword: " + keyword + "\nTo Policy Area: " + policyArea.getName());
    }

    public void keywordTrendingUpdate(String trendingKeyword)
    {
        System.out.println("Keyword: " + trendingKeyword + "is Trending");
    }

    public void talkingPointUpdate(String keyword, PolicyAreaObserver policyArea)
    {
        System.out.println("Added Talking Point: " + keyword + "\nTo Policy Area: " + policyArea.getName());
    }
    
}