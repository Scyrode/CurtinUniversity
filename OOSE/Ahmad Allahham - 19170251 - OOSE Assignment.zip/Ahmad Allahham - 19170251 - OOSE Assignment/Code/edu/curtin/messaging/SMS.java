package edu.curtin.messaging;

/**
 * SMS
 */
public class SMS {

    public SMS()
    {

    }

    /** Sends an SMS to a given phone number. */
    public void sendSMS(long mobileNumber, String message)
    {
        
    }

    
}