package edu.curtin.messaging;

import java.util.Map;

/**
 * FacebookNotifier
 */
public class FacebookNotifier extends FacebookMessenger {

    protected void keywordsDetected(Map<String,Integer> keywords, long timestamp)
    {
        
    }
    
}