package edu.curtin.messaging;

import java.util.Map;

/**
 * TwitterNotifier
 */
public class TwitterNotifier extends TwitterMessenger {

    protected void keywordsDetected(Map<String,Integer> keywords, long timestamp)
    {
        
    }
    
}