package model;

import java.util.Map;

/**
 * StrategistObserver
 */
public class StrategistObserver extends PersonObserver {

    public StrategistObserver(int id, String name, String type, Map<String, String> contactDetails) {
        super(id, name, type, contactDetails);
    }

    @Override public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea) {}
    
    @Override public void keywordTrendingUpdate(String trendingKeyword)
    {
        System.out.println(this.getName() + ": " + "the following Word is trending: " + trendingKeyword + "\n");
    }
    
    @Override public void talkingPointUpdate(String talkingPoint, PolicyAreaObserver policyArea)
    {
        System.out.println(this.getName() + ": " + "the following talking point has been added to " + policyArea.getName() + ": " + talkingPoint + "\n");
    }
    
}