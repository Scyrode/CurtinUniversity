package model;

import java.util.HashSet;
import java.util.Set;

import controller.Exceptions.AddKeywordException;
import controller.Exceptions.AddTalkingPointException;
import controller.Exceptions.RemoveKeywordException;
import controller.Exceptions.RemoveTalkingPointException;
import view.NotificationViewer;
import model.Exceptions.*;

/**
 * NotificationsManager
 */
public class NotificationsManager implements NotificationsManagerInterface {

    public Set<PersonObserver> personObservers;
    public Set<PolicyAreaObserver> policyAreaObservers;

    /* added as a seperate observer. In reality, it 
    should be added as a person and policy observer */
    private NotificationViewer view;

    public NotificationsManager()
    {
        personObservers = new HashSet<>();
        policyAreaObservers = new HashSet<>();
    }
    
    public boolean addObserver(PersonObserver person)
    {
        return personObservers.add(person);
    }

    public boolean addObserver(PolicyAreaObserver policyArea)
    {
        return policyAreaObservers.add(policyArea);
    }

    public boolean addObserver(NotificationViewer view)
    {
        // only used once in view - definite return
        this.view = view;
        return true;
    }

    public boolean removeObserver(int presonId)
    {

        PersonObserver person = null;
        boolean result = false;

        for (PersonObserver currentPerson : personObservers)
        {
            if (currentPerson.getId() == presonId)
            {
                person = currentPerson;
            }
        }

        try {
            result = personObservers.remove(person);
        } catch (NullPointerException e) {
            result = false;
        }
        
        return result;
        
    }
    
    public boolean removeObserver(String name)
    {

        PolicyAreaObserver policyArea = null;
        boolean result = false;

        for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
        {
            if (currentPolicyArea.getName().equalsIgnoreCase(name))
            {
                policyArea = currentPolicyArea;
            }
        }

        try {
            policyAreaObservers.remove(policyArea);
            result = true;
        } catch (NullPointerException e) {
            result = false;
        }

        return result;
        
    }
    
    public void addNotificationSetting(int personId, String policyAreaName) throws AddNotificationException
    {

        PersonObserver person = null;
        PolicyAreaObserver policyArea = null;

        try {

            for (PersonObserver currentPerson : personObservers)
            {
                if (currentPerson.getId() == personId)
                {
                    person = currentPerson;
                }
            }

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            if (!policyArea.getExtraPeopleInvolved().add(person))
            {
                throw new AddNotificationException("Extra Notification already exists");
            }
            
        } catch (NullPointerException e) {
            throw new AddNotificationException("Person or Policy Area does not exist");
        }
        
    }
    
    public void removeNotificationSetting(int personId, String policyAreaName) throws RemoveNotificationException
    {

        PersonObserver person = null;
        PolicyAreaObserver policyArea = null;

        /* attempts to find the person and the policyArea,
        if either of them are missing, it throws an exception */

        try {

            for (PersonObserver currentPerson : personObservers)
            {
                if (currentPerson.getId() == personId)
                {
                    person = currentPerson;
                }
            }

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            if (!policyArea.getExtraPeopleInvolved().remove(person))
            {
                throw new RemoveNotificationException("Extra Notification does not exist");
            }
            
        } catch (NullPointerException e) {
            throw new RemoveNotificationException("Person or Policy Area does not exist");
        }

    }

    public void addKeyword(String keyword, String policyAreaName) throws AddKeywordException
    {

        PolicyAreaObserver policyArea = null;

        try {

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            // MUST DO THIS IN THE CORRECT POLICYAREA (updateNewKeyword())
            // result = policyArea.getKeywords().add(keyword);

            this.notifyNewKeyword(keyword, policyArea);
            
        } catch (NullPointerException e) {
            throw new AddKeywordException("Policy Area Does Not Exist");
        }

    }

    public boolean removeKeyword(String keyword, String policyAreaName) throws RemoveKeywordException
    {

        PolicyAreaObserver policyArea = null;
        boolean result = false;

        try {

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            result = policyArea.getKeywords().remove(keyword);
            
        } catch (NullPointerException e) {
            throw new RemoveKeywordException("Policy Area Does Not Exist");
        }

        return result;

    }

    public void addTalkingPoint(String talkingPoint, String policyAreaName) throws AddTalkingPointException
    {

        PolicyAreaObserver policyArea = null;

        try {

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            // MUST BE DONE IN THE CORRECT POLOCY AREA (updateTalkingPoint())
            // result = policyArea.getTalkingPoints().add(talkingPoint);
            
            this.notifyNewTalkingPoint(talkingPoint, policyArea);
            
        } catch (NullPointerException e) {
            throw new AddTalkingPointException("Policy Area Does Not Exist");
        } 

    }

    public boolean removeTalkingPoint(String talkingPoint, String policyAreaName) throws RemoveTalkingPointException
    {

        PolicyAreaObserver policyArea = null;
        boolean result = false;

        try {

            for (PolicyAreaObserver currentPolicyArea : policyAreaObservers)
            {
                if (currentPolicyArea.getName().equalsIgnoreCase(policyAreaName))
                {
                    policyArea = currentPolicyArea;
                }
            }

            result = policyArea.getTalkingPoints().remove(talkingPoint);
            
        } catch (NullPointerException e) {
            throw new RemoveTalkingPointException("Policy Area Does Not Exist");
        }

        return result;

    }

    public String displayPeople()
    {
        
        String output = "\n";

        for (PersonObserver person : personObservers)
        {
            output += person.toString();
        }

        return output;
        
    }

    public String displayPolicyAreas()
    {

        String output = "\n";

        for (PolicyAreaObserver policyArea : policyAreaObservers)
        {
            output += policyArea.toString();
        }

        return output;

    }
    
    public void notifyNewKeyword(String keyword, PolicyAreaObserver policyArea) throws AddKeywordException
    {
        
        for (PersonObserver person : this.personObservers)
        {
            person.newKeywordUpdate(keyword, policyArea);
        }

        for (PolicyAreaObserver currentPolicyArea : this.policyAreaObservers)
        {
            currentPolicyArea.newKeywordUpdate(keyword, policyArea);
        }
        
    }
    
    public void notifyKeywordTrending(String trendingKeyword)
    {

        for (PersonObserver person : this.personObservers)
        {
            person.keywordTrendingUpdate(trendingKeyword);
        }
        
        for (PolicyAreaObserver policyArea : this.policyAreaObservers)
        {
            policyArea.keywordTrendingUpdate(trendingKeyword);
        }

    }
    
    public void notifyNewTalkingPoint(String talkingPoint, PolicyAreaObserver policyArea) throws AddTalkingPointException
    {

        for (PersonObserver person : this.personObservers)
        {
            person.talkingPointUpdate(talkingPoint, policyArea);
        }

        for (PolicyAreaObserver currentPolicyArea : this.policyAreaObservers)
        {
            currentPolicyArea.talkingPointUpdate(talkingPoint, policyArea);
        }
        
    }
    
}