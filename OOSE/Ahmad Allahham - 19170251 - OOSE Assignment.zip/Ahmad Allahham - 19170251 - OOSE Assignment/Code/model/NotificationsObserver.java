package model;

/**
 * NotificationsObserver
 */
public interface NotificationsObserver {

    public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea);
    public void keywordTrendingUpdate(String trendingKeyword);
    public void talkingPointUpdate(String keyword, PolicyAreaObserver policyArea);
    
}