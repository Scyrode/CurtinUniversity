package model;

import controller.Exceptions.AddKeywordException;
import controller.Exceptions.AddTalkingPointException;
import controller.Exceptions.RemoveKeywordException;
import controller.Exceptions.RemoveTalkingPointException;
import model.Exceptions.AddNotificationException;
import model.Exceptions.RemoveNotificationException;
import view.NotificationViewer;

/**
 * NotificationsManagerInterface
 */
public interface NotificationsManagerInterface {

    public boolean addObserver(PersonObserver person);
    public boolean addObserver(PolicyAreaObserver policyArea);
    public boolean addObserver(NotificationViewer view);
    public boolean removeObserver(int presonId);
    public boolean removeObserver(String name);
    public void addNotificationSetting(int personId, String policyAreaName) throws AddNotificationException;
    public void removeNotificationSetting(int personId, String policyAreaName) throws RemoveNotificationException;
    public void addKeyword(String keyword, String policyAreaName) throws AddKeywordException;
    public boolean removeKeyword(String keyword, String policyAreaName) throws RemoveKeywordException;
    public void addTalkingPoint(String talkingPoint, String policyAreaName) throws AddTalkingPointException;
    public boolean removeTalkingPoint(String talkingPoint, String policyAreaName) throws RemoveTalkingPointException;
    public String displayPeople();
    public String displayPolicyAreas();
    public void notifyNewKeyword(String keyword, PolicyAreaObserver policyArea) throws AddKeywordException;
    public void notifyKeywordTrending(String trendingKeyword);
    public void notifyNewTalkingPoint(String talkingPoint, PolicyAreaObserver policyArea) throws AddTalkingPointException;
    
}