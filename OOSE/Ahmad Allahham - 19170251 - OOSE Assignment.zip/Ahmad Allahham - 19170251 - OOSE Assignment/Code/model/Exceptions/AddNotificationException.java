package model.Exceptions;

/**
 * AddNotificationException
 */
public class AddNotificationException extends Exception {

    public AddNotificationException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public AddNotificationException(String messsage)
    {
        super(messsage);
    }

    public AddNotificationException(Throwable cause)
    {
        super(cause);
    }
    
}