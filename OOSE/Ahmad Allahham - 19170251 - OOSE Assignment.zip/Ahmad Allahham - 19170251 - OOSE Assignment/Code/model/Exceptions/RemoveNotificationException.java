package model.Exceptions;
/**
 * RemoveNotificationException
 */
public class RemoveNotificationException extends Exception {

    public RemoveNotificationException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public RemoveNotificationException(String messsage)
    {
        super(messsage);
    }

    public RemoveNotificationException(Throwable cause)
    {
        super(cause);
    }
    
}