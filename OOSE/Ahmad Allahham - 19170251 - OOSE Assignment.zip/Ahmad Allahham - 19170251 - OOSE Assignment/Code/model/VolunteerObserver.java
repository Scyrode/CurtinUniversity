package model;

import java.util.Map;

/**
 * VolunteerObserver
 */
public class VolunteerObserver extends PersonObserver {

    public VolunteerObserver(int id, String name, String type, Map<String, String> contactDetails) {
        super(id, name, type, contactDetails);
    }

    @Override public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea)
    {
        System.out.println(this.getName() + ": " + "the following keyword has been added to " + policyArea.getName() + ": " + keyword + "\n");
    }

    @Override public void keywordTrendingUpdate(String trendingKeyword)
    {
        System.out.println(this.getName() + ": " + "the following Word is trending: " + trendingKeyword + "\n");
    }
    
    @Override public void talkingPointUpdate(String talkingPoint, PolicyAreaObserver policyArea)
    {
        System.out.println(this.getName() + ": " + "the following talking point has been added to " + policyArea.getName() + ": " + talkingPoint + "\n");
    }
    
}