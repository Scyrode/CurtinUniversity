package model;

import java.util.Map;

/**
 * PersonObserver
 */
public abstract class PersonObserver implements NotificationsObserver {

    private int id;
    private String name;
    private String type;
    private Map<String,String> contactDetails;

    public PersonObserver(int id, String name, String type, Map<String,String> contactDetails)
    {
        this.id = id;
        this.name = name;
        this.type = type;
        this.contactDetails = contactDetails;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the contactDetails
     */
    public Map<String, String> getContactDetails() {
        return contactDetails;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param contactDetails the contactDetails to set
     */
    public void setContactDetails(Map<String, String> contactDetails) {
        this.contactDetails = contactDetails;
    }

    public String toString()
    {
        return "Name: " + this.name + ", Type: " + this.type + ", ID: " + this.id + ", Contact Details: " + this.contactDetails.toString() + "\n";
    }

    @Override public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea) {}
    @Override public void keywordTrendingUpdate(String trendingKeyword) {}
    @Override public void talkingPointUpdate(String talkingPoint, PolicyAreaObserver policyArea) {}
    
}