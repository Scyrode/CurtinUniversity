package model;

import java.util.Map;

/**
 * CandidateObserver
 */
public class CandidateObserver extends PersonObserver {

    public CandidateObserver(int id, String name, String type, Map<String, String> contactDetails) {
        super(id, name, type, contactDetails);
    }

    @Override public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea) {}

    @Override public void keywordTrendingUpdate(String trendingKeyword) {}
    
    @Override public void talkingPointUpdate(String talkingPoint, PolicyAreaObserver policyArea)
    {
        System.out.println(this.getName() + ": " + "the following talking point has been added to " + policyArea.getName() + ": " + talkingPoint + "\n");
    }
    
}