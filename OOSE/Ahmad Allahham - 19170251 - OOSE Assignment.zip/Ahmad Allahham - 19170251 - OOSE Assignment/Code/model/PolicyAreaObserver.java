package model;

import java.util.HashSet;
import java.util.Set;

/**
 * PolicyAreaObserver
 */
public class PolicyAreaObserver implements NotificationsObserver{

    private String name;
    private Set<String> keywords;
    private Set<String> talkingPoints;
    private Set<PersonObserver> extraPeopleInvolved;

    public PolicyAreaObserver(String name, Set<String> keywords, Set<String> talkingPoints)
    {
        this.name = name;
        this.keywords = keywords;
        this.talkingPoints = talkingPoints;
        this.extraPeopleInvolved = new HashSet<>();
    }

    public PolicyAreaObserver(String name)
    {
        this.name = name;
        this.keywords = new HashSet<>();
        this.talkingPoints = new HashSet<>();
        this.extraPeopleInvolved = new HashSet<>();
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the keywords
     */
    public Set<String> getKeywords() {
        return keywords;
    }

    /**
     * @return the talkingPoints
     */
    public Set<String> getTalkingPoints() {
        return talkingPoints;
    }

    /**
     * @return the extraPeopleInvolved
     */
    public Set<PersonObserver> getExtraPeopleInvolved() {
        return extraPeopleInvolved;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param keywords the keywords to set
     */
    public void setKeywords(Set<String> keywords) {
        this.keywords = keywords;
    }

    /**
     * @param talkingPoints the talkingPoints to set
     */
    public void setTalkingPoints(Set<String> talkingPoints) {
        this.talkingPoints = talkingPoints;
    }

    /**
     * @param extraPeopleInvolved the extraPeopleInvolved to set
     */
    public void setExtraPeopleInvolved(Set<PersonObserver> extraPeopleInvolved) {
        this.extraPeopleInvolved = extraPeopleInvolved;
    }

    public String toString()
    {
        if (extraPeopleInvolved.size() == 0)
        {
            return "Policy Area Name: " + this.name + ", Keywords: " + this.keywords.toString() + ", Talking Points: " + this.talkingPoints.toString() + "\n";
        } else
        {
            return "Policy Area Name: " + this.name + ", Extra People Involved: " + this.extraPeopleInvolved.toString() + ", Keywords: " + this.keywords.toString() + ", Talking Points: " + this.talkingPoints.toString() + "\n";
        }
    }

    @Override public void newKeywordUpdate(String keyword, PolicyAreaObserver policyArea)
    {
        for (String word : this.getKeywords())
        {
            if (word.equals(keyword))
            {
                if (this.getExtraPeopleInvolved() != null)
                {
                    for (PersonObserver person : this.getExtraPeopleInvolved())
                    {
                        System.out.println(person.getName() + ": the following keyword has been added to " + this.getName() + ": " + keyword);
                    }

                    this.getKeywords().add(keyword);
                    
                }
            }
        }
    }

    @Override public void keywordTrendingUpdate(String trendingKeyword)
    {
        for (String word : this.getKeywords())
        {
            if (word.equals(trendingKeyword))
            {
                System.out.println(this.getName() + ": the following keyword is trending: " + trendingKeyword);
            }
        }
    }

    @Override public void talkingPointUpdate(String talkingPoint, PolicyAreaObserver policyArea)
    {
        for (String currentTalkingPoint : this.getTalkingPoints())
        {
            if (currentTalkingPoint.equals(talkingPoint))
            {
                if (this.getExtraPeopleInvolved() != null)
                {
                    
                    for (PersonObserver person : this.getExtraPeopleInvolved())
                    {
                        System.out.println(person.getName() + ": the following talking Point has been added to " + this.getName() + ": " + talkingPoint);
                    }

                    this.getTalkingPoints().add(talkingPoint);
                    
                }
            }
        }
    }
    
}