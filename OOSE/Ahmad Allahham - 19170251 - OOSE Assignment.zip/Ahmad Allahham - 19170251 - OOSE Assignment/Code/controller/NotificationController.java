/**
 * NotificationController
 */

package controller;
 
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import edu.curtin.messaging.*;
import model.*;
import model.Exceptions.AddNotificationException;
import model.Exceptions.RemoveNotificationException;
import view.NotificationViewer;
import controller.Exceptions.*;
 
public class NotificationController implements NotificationControllerInterface {

    private NotificationsManager notificationManager;
    private NotificationViewer notificationViewer;
    private ObserverFactory observerFactory;
    private SMS smsNotifier;
    private TwitterNotifier twitterNotifier;
    private FacebookNotifier facebookNotifier;
    private int refreshPeriod;
    private Date dateObject;
    
    public NotificationController(NotificationsManager notificationManager,
    TwitterNotifier twitterNotifier, FacebookNotifier facebookNotifier, SMS smsNotifier)
    {

        // intialise the model and the view
        this.notificationManager = notificationManager;
        notificationViewer = new NotificationViewer(this.notificationManager, this);

        // intialise the facebook, twitter and sms notifiers
        this.twitterNotifier = twitterNotifier;
        this.facebookNotifier = facebookNotifier;
        this.smsNotifier = smsNotifier;

        // intialise the refresh period, in code, the refresh period is 5 secs, however this represents 1 Hour
        refreshPeriod = 1000 * 5;

        /* intialise the Date Object to the current Date and time
        (used for checking if keyword has been trending for the past 24 hours - 2 mins in code) */
        dateObject = new Date();

        observerFactory = new ObserverFactory();

    }
    
    public void start()
    {
        
        notificationViewer.displayWelcomeMenu();
        notificationViewer.displayInitialMenu();
        
    }

    public void addPerson(String name, String type, int id, Map<String, String> contactDetails) throws AddPersonException
    {

        try {

            boolean isAdded = notificationManager.addObserver(observerFactory.makePerson(name, type, id, contactDetails));

            if (!isAdded)
            {
                throw new AddPersonException("Person already exists");
            }
            
        } catch (MakePersonException e) {
            throw new AddPersonException(e.getMessage());
        }
        

    }

    // method overloading: adding a person to the model by importing a PersonObserver
    public void addPerson(PersonObserver person) throws AddPersonException
    {

        boolean isAdded = notificationManager.addObserver(person);

        if (!isAdded)
        {
            throw new AddPersonException("Person already exists");
        }
        
    }

    
    public void removePerson(int id) throws RemovePersonException
    {

        boolean isRemoved = notificationManager.removeObserver(id);

        if (!isRemoved)
        {
            throw new RemovePersonException("Person does not exist");
        }
        

    }
    
    public String displayPeople()
    {
        return notificationManager.displayPeople();
    }
    
    public void addPolicyArea(String name) throws AddPolicyAreaException
    {

        try {

            boolean isAdded = notificationManager.addObserver(observerFactory.makePolicyArea(name));

            if (!isAdded)
            {
                throw new AddPolicyAreaException("Policy Area Already Exists");
            }
            
        } catch (MakePolicyAreaException e) {
            throw new AddPolicyAreaException(e.getMessage());
        }

    }

    // method overloading: adding a policy area to the model by importing a PolicyAreaObserver
    public void addPolicyArea(PolicyAreaObserver policyArea) throws AddPolicyAreaException
    {

        boolean isAdded = notificationManager.addObserver(policyArea);

        if (!isAdded)
        {
            throw new AddPolicyAreaException("Policy Area Already Exists");
        }

    }

    public void removePolicyArea(String policyAreaName) throws RemovePolicyAreaException
    {

        boolean isRemoved = notificationManager.removeObserver(policyAreaName);

        if (!isRemoved)
        {
            throw new RemovePolicyAreaException("Policy Area Does Not Exist");
        }

    }

    public String displayPolicyAreas()
    {
        return notificationManager.displayPolicyAreas();
    }

    public void readInfo() throws ReadInfoException
    {

        IOClass IOObject = new IOClass(observerFactory);

        try {

            Set<PersonObserver> peopleRead = IOObject.readPersonFile();
            Set<PolicyAreaObserver> policyAreasRead = IOObject.readPolicyAreaFile();

            try {
                
                for (PersonObserver person : peopleRead)
                {
                    if (person != null)
                    {
                        this.addPerson(person);
                    }
                }
                
            } catch (AddPersonException e) {
                throw new ReadInfoException("Error adding poeple from file");
            } 
    
            try {
    
                for (PolicyAreaObserver policyArea : policyAreasRead)
                {
                    this.addPolicyArea(policyArea);
                }
                
            } catch (AddPolicyAreaException e) {
                throw new ReadInfoException("Error adding policy areas from file");
            }
            
        } catch (IOClassException e) {
            throw new ReadInfoException(e.getMessage());
        }
        
        
    }

    public void writeInfo() {}

    public void addNotificationSetting(int personId, String policyAreaName) throws AddNotificationException
    {
        notificationManager.addNotificationSetting(personId, policyAreaName);
    }
    
    public void removeNotificationSetting(int personId, String policyAreaName) throws RemoveNotificationException
    {
        notificationManager.removeNotificationSetting(personId, policyAreaName);
    }

    public void addKeyword(String keyword, String policyAreaName) throws AddKeywordException
    {

        notificationManager.addKeyword(keyword, policyAreaName);

    }

    public void removeKeyword(String keyword, String policyAreaName) throws RemoveKeywordException
    {

        boolean isRemoved = notificationManager.removeKeyword(keyword, policyAreaName);

        if (!isRemoved)
        {
            throw new RemoveKeywordException("Keyword does not exist");
        }
        
    }

    public void addTalkingPoint(String talkingPoint, String policyAreaName) throws AddTalkingPointException
    {

        notificationManager.addTalkingPoint(talkingPoint, policyAreaName);

    }

    public void removeTalkingPoint(String talkingPoint, String policyAreaName) throws RemoveTalkingPointException
    {

        boolean isRemoved = notificationManager.removeTalkingPoint(talkingPoint, policyAreaName);

        if (!isRemoved)
        {
            throw new RemoveTalkingPointException("Keyword does not exist");
        }

    }

    // NOT COMPLETED
    public void monitoringThread(Timer timer)
    {
        
        // schedule the search for trending keywords to be done every so often
        // timer.schedule(new TimerTask(){
        
        //     @Override
        //     public void run() {

        //         for (PolicyAreaObserver policyArea : notificationManager.policyAreaObservers)
        //         {

        //             Map<String, Integer> keywords = new HashMap<>();
        //             twitterNotifier.setKeywords(policyArea.getKeywords());

        //             
        //             - cycle through all the keyword sets
        //             - for each set of keywords, use the function setKeywords in TwitterMessenger
        //               & FacebookMessenger to populate the keywords in the Keywords Map
        //             - use the KeywordsDetected method to store the number of occurences
        //               of the keywords stored in the Map.
        //             - in the run method, if the currentKeyword has more than 50 occurences, 
        //               call the notifyKeywordTrending() method in the model
                    
        //         }
                    
        //     }

        // }, delay, refreshPeriod);
        
    }
    
}