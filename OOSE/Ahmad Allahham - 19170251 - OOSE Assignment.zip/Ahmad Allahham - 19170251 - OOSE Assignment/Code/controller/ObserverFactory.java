/**
 * ObserverFactory
 */

package controller;
 
import java.util.Map;
import java.util.Set;

import controller.Exceptions.*;
import model.*;

public class ObserverFactory {

    public PersonObserver makePerson(String name, String type, int id, Map<String,String> contactDetails) throws MakePersonException
    {

        PersonObserver person;
        
        try {

            if (type.equalsIgnoreCase("volunteer"))
            {
                person = new VolunteerObserver(id, name, type, contactDetails);
            } else if (type.equalsIgnoreCase("strategist")) {
                person = new StrategistObserver(id, name, type, contactDetails);
            } else if (type.equalsIgnoreCase("candidate"))
            {
                person = new CandidateObserver(id, name, type, contactDetails);
            } else
            {
                throw new MakePersonException("Type of person is invalid");
            }
            
        } catch (IllegalArgumentException e) {
            throw new MakePersonException("Person Details Invalid");
        }

        return person;
        
    }

    public PolicyAreaObserver makePolicyArea(String name) throws MakePolicyAreaException
    {

        PolicyAreaObserver policyArea;
        
        if (name != null && !name.equals(""))
        {
            policyArea = new PolicyAreaObserver(name);
        } else
        {
            throw new MakePolicyAreaException("Invalid Policy Area Name");
        }

        return policyArea;

    }

    public PolicyAreaObserver makePolicyArea(String name, Set<String> keywords, Set<String> talkingPoints) throws MakePolicyAreaException
    {

        PolicyAreaObserver policyArea;

        if (name != null && !name.equals(""))
        {
            policyArea = new PolicyAreaObserver(name, keywords, talkingPoints);
        } else
        {
            throw new MakePolicyAreaException("Invalid Policy Area Name");
        }
        
        return policyArea;
        
    }
    
}