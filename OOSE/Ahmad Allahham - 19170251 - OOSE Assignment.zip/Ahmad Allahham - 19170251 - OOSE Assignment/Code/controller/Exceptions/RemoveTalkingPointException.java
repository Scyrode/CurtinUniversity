package controller.Exceptions;

/**
 * RemoveTalkingPointException
 */
public class RemoveTalkingPointException extends Exception {

    public RemoveTalkingPointException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public RemoveTalkingPointException(String messsage)
    {
        super(messsage);
    }

    public RemoveTalkingPointException(Throwable cause)
    {
        super(cause);
    }
    
}