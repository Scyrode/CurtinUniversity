package controller.Exceptions;

/**
 * RemovePersonException
 */
public class RemovePersonException extends Exception {

    public RemovePersonException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public RemovePersonException(String messsage)
    {
        super(messsage);
    }

    public RemovePersonException(Throwable cause)
    {
        super(cause);
    }
    
}