package controller.Exceptions;

/**
 * AddPersonException
 */
public class AddPersonException extends Exception {

    public AddPersonException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public AddPersonException(String messsage)
    {
        super(messsage);
    }

    public AddPersonException(Throwable cause)
    {
        super(cause);
    }
    
}