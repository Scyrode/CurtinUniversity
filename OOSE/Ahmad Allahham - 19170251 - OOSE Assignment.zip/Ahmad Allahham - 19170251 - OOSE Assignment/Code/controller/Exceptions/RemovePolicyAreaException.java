package controller.Exceptions;

/**
 * RemovePolicyAreaException
 */
public class RemovePolicyAreaException extends Exception {

    public RemovePolicyAreaException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public RemovePolicyAreaException(String messsage)
    {
        super(messsage);
    }

    public RemovePolicyAreaException(Throwable cause)
    {
        super(cause);
    }
    
}