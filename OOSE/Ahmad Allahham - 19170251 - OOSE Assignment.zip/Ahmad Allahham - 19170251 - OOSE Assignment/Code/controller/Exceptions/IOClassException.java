package controller.Exceptions;

/**
 * IOClassException
 */
public class IOClassException extends Exception {

    public IOClassException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public IOClassException(String messsage)
    {
        super(messsage);
    }

    public IOClassException(Throwable cause)
    {
        super(cause);
    }
    
}