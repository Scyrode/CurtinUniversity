package controller.Exceptions;

/**
 * AddPolicyAreaException
 */
public class AddPolicyAreaException extends Exception {

    public AddPolicyAreaException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public AddPolicyAreaException(String messsage)
    {
        super(messsage);
    }

    public AddPolicyAreaException(Throwable cause)
    {
        super(cause);
    }
    
}