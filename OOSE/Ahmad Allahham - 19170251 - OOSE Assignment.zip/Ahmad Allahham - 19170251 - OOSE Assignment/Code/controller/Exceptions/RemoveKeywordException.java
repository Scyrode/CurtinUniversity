package controller.Exceptions;

/**
 * RemoveKeywordException
 */
public class RemoveKeywordException extends Exception {

    public RemoveKeywordException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public RemoveKeywordException(String messsage)
    {
        super(messsage);
    }

    public RemoveKeywordException(Throwable cause)
    {
        super(cause);
    }
    
}