package controller.Exceptions;

/**
 * MakePolicyAreaException
 */
public class MakePolicyAreaException extends Exception {

    public MakePolicyAreaException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public MakePolicyAreaException(String messsage)
    {
        super(messsage);
    }

    public MakePolicyAreaException(Throwable cause)
    {
        super(cause);
    }
    
}