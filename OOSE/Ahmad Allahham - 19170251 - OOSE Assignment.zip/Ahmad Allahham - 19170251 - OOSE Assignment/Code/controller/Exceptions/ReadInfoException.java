package controller.Exceptions;

/**
 * ReadInfoException
 */
public class ReadInfoException extends Exception {

    public ReadInfoException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public ReadInfoException(String messsage)
    {
        super(messsage);
    }

    public ReadInfoException(Throwable cause)
    {
        super(cause);
    }
    
}