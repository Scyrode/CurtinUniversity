package controller.Exceptions;

/**
 * AddTalkingPointException
 */
public class AddTalkingPointException extends Exception {

    public AddTalkingPointException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public AddTalkingPointException(String messsage)
    {
        super(messsage);
    }

    public AddTalkingPointException(Throwable cause)
    {
        super(cause);
    }
    
}