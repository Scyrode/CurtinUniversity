package controller.Exceptions;

/**
 * MakePersonException
 */
public class MakePersonException extends Exception {

    public MakePersonException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public MakePersonException(String messsage)
    {
        super(messsage);
    }

    public MakePersonException(Throwable cause)
    {
        super(cause);
    }
    
}