package controller.Exceptions;

/**
 * AddKeywordException
 */
public class AddKeywordException extends Exception {

    public AddKeywordException(String messsage, Throwable cause)
    {
        super(messsage, cause);
    }

    public AddKeywordException(String messsage)
    {
        super(messsage);
    }

    public AddKeywordException(Throwable cause)
    {
        super(cause);
    }
    
}