/**
 * NotificationControllerInterface
 */

package controller;

import java.util.Map;
import java.util.Timer;

import model.*;
import model.Exceptions.AddNotificationException;
import model.Exceptions.RemoveNotificationException;
import controller.Exceptions.*;

public interface NotificationControllerInterface {

    public void start();
    public void addPerson(String name, String type, int id, Map<String, String> contactDetails) throws AddPersonException;
    public void addPerson(PersonObserver person) throws AddPersonException;
    public void removePerson(int id) throws RemovePersonException;
    public String displayPeople();
    public void addPolicyArea(String name) throws AddPolicyAreaException;
    public void addPolicyArea(PolicyAreaObserver policyArea) throws AddPolicyAreaException;
    public void removePolicyArea(String policyAreaName) throws RemovePolicyAreaException;
    public String displayPolicyAreas();
    public void readInfo() throws ReadInfoException;
    public void writeInfo();
    public void addNotificationSetting(int personId, String policyAreaName) throws AddNotificationException;
    public void removeNotificationSetting(int personId, String policyAreaName) throws RemoveNotificationException;
    public void addKeyword(String keyword, String policyAreaName) throws AddKeywordException;
    public void removeKeyword(String keyword, String policyAreaName) throws RemoveKeywordException;
    public void addTalkingPoint(String talkingPoint, String policyAreaName) throws AddTalkingPointException;
    public void removeTalkingPoint(String talkingPoint, String policyAreaName) throws RemoveTalkingPointException;
    public void monitoringThread(Timer timer);
    
}