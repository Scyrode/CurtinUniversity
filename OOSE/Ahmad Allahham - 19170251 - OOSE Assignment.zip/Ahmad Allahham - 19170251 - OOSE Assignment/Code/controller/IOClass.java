/**
 * IOClass
 */

package controller;
 
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import controller.Exceptions.IOClassException;
import controller.Exceptions.MakePersonException;
import controller.Exceptions.MakePolicyAreaException;
import model.*;

public class IOClass {

    private ObserverFactory observerFactory;

    public IOClass(ObserverFactory observerFactory)
    {
        this.observerFactory = observerFactory;
    }

    public Set<PersonObserver> readPersonFile() throws IOClassException
    {

        Set<PersonObserver> people = new HashSet<>();
        String[] lines;

        // fake input to geenrate volunteers, candidates and strategists
        String peopleDetails = "Althea K. Pacheco,Volunteer,748395,045687394,althea_Pacheco,@AltheaP\nJustin K. Zeigler,Candidate,936583,034957635,,\nJimmy E. Stevens,Volunteer,846574,,jimmyWimmy,\nMargery K. Patterson,Strategist,342647,044857987,Marg_K,@Marg_Patterson\nJanet R. Brodersen,Strategist,568439,,JannetBrad,@Jane_Brad\nHarvey T. Patterson,Volunteer,039506,,,@Patterson_Harve\nKenneth D. Mason,Candidate,943958,048465748,KenMas,@Kenneth_Mason";

        // split the input into tokens (used of generating the list of people)
        lines = peopleDetails.split("\n");

        // use each line to create a PersonObserver Object
        for (String line : lines)
        {
            
            Map<String, String> contactDetails = new HashMap<>();
            String[] currentLine = line.split(",", -1);

            /* for the last three tokens (tokens that record person's contact details),
            if not empty, then store it as a contact detail */
            if (!currentLine[3].equals(""))
            {
                contactDetails.put("SMS", currentLine[3]);
            }
            if (!currentLine[4].equals(""))
            {
                contactDetails.put("Facebook", currentLine[4]);
            }
            if (!currentLine[5].equals(""))
            {
                contactDetails.put("Twitter", currentLine[5]);
            }

            /* use observer factory to create a person of the right type
            then store that person in the list of people */
            try {
                people.add(observerFactory.makePerson(currentLine[0], currentLine[1], Integer.parseInt(currentLine[2]), contactDetails));
            } catch (MakePersonException e) {
                throw new IOClassException(e.getMessage());
            }
            
        }

        return people;

    }

    public Set<PolicyAreaObserver> readPolicyAreaFile() throws IOClassException
    {
        
        Set<PolicyAreaObserver> policyAreas = new HashSet<>();
        String policyAreaList[];
        String keywordsLineList[];
        String talkingPointsLineList[];

        /* use fake input for the policy Area Names, Keywords,
        and Talking Points to create a set of PolicyAreaObservers */
        
        String policyAreaDetails = "Education\nDefence\nWorkplace Relations\nHealth\nStartups and Small Businesses\n";

        String keywordsCollection = "Education,Schools,Teachers,STEM,Funds\nDefence,Army,Veterans,Security,Immigrants\nWorkplace Relations,Taxes,Grants,Job Cuts,Oil and Gas Industry\nHealth,Hospitlas,Children,Vaccines,Health Insurance\nStartups and Small Businesses,Hackathon,Conference,Grants,Workshops";

        String talkingPointsCollection = "Education,Focus on STEM Education,Grants for Schools\nDefence,Homes for Returning Veterans\nWorkplace Relations,Cut Taxes,Financial Aid for Relieved Workers\nHealth,Free Health Insurance for Children Under 8 Years,Free Vaccines for All Children\nStartups and Small Businesses,New Tech Conference in Sydeney, Grants for Startups and Small Businesses";

        // split the long Strings into individual lines
        policyAreaList = policyAreaDetails.split("\n");
        keywordsLineList = keywordsCollection.split("\n");
        talkingPointsLineList = talkingPointsCollection.split("\n");
        
        /* for each policy area, record its keywords and 
        talking points then use the ObserverFactory to create
        the list of PolicyAreaObservers */
        for (String policyArea : policyAreaList)
        {

            Set<String> keywords = new HashSet<>();
            Set<String> talkingPoints = new HashSet<>();

            for (String currentKeywordLine : keywordsLineList)
            {

                String[] currentKeywords = currentKeywordLine.split(",");

                if (currentKeywords[0].equals(policyArea))
                {
                    for (int i = 1; i < currentKeywords.length; i++)
                    {
                        keywords.add(currentKeywords[i]);
                    }
                }
                
            }

            for (String currentTalkingPointLine : talkingPointsLineList)
            {

                String[] currentTalkingPoints = currentTalkingPointLine.split(",");

                if (currentTalkingPoints[0].equals(policyArea))
                {
                    for (int i = 1; i < currentTalkingPoints.length; i++)
                    {
                        talkingPoints.add(currentTalkingPoints[i]);
                    }
                }
                
            }
            
            try {
                policyAreas.add(observerFactory.makePolicyArea(policyArea, keywords, talkingPoints));
            } catch (MakePolicyAreaException e) {
                throw new IOClassException(e.getMessage());
            }
            
        }

        return policyAreas;
        
    }
    
}