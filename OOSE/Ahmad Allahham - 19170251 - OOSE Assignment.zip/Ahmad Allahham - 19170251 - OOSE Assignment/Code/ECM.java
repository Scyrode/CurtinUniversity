/**
 * ECM
 */

import java.util.Timer;

import controller.*;
import edu.curtin.messaging.*;
import model.*;

public class ECM {

    public static void main(String[] args) {

        // create the necessary variables for the Controller

        NotificationsManager notificationManager = new NotificationsManager();
        TwitterNotifier twitterMessenger = new TwitterNotifier();
        FacebookNotifier facebookMessenger = new FacebookNotifier();
        SMS smsNotifier = new SMS();
        Timer timer = new Timer();

        // intialise application
        NotificationController notificationController = new NotificationController(notificationManager, twitterMessenger, facebookMessenger, smsNotifier);

        // start the application
        notificationController.start();

        // begin monitoring thread
        notificationController.monitoringThread(timer);
        
    }
    
}