HOW TO COMPILE (IGNORE WARNINGS):
TASK1:
gcc Task1.c Functions.c -o Task1
TASK2:
gcc Task2.c Functions.c -o Task2
TASK3:
gcc Task3.c Functions.c -pthread -o Task3

HOW TO RUN:
TASK1:
./Task1
TASK2:
./Task2
TASK3:
./Task3